<?php

$a = 2;
echo " а = {$a} \n";
++$a;
echo "++a = {$a} \n";
$a *= 5;
echo "a *= 5 = {$a} \n";
$a **= 2;
echo "a **= 2 = {$a} \n";

