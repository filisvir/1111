<?php
    print 'How are you?';
    print "I'm fine. ";
?>
